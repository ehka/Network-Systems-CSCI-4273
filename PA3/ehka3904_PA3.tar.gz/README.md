Ehsan Karimi  PA3

How to run:
exactly as explained in the PA3 writeup.


Note:
No extra credit was implemented.


